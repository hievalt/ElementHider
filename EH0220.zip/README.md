# ElementHider
Chrome Extension that hides elements from webpage based on user set keywords.

Elements can be hidden or blurred.

Includes testing mode which highlights the elements instead of hiding them so it is easy to observe the effect of current keywords.

Chrome Webstore: https://chrome.google.com/webstore/detail/elementhider/jnbamieaacddlfcoanmbkclnpoafhmie
